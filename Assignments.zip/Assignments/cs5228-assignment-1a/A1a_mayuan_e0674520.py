import numpy as np

from sklearn.metrics.pairwise import euclidean_distances


def get_noise_dbscan(X, eps=0.0, min_samples=0):
    
    core_point_indices, noise_point_indices = None, None
    
    #########################################################################################
    ### Your code starts here ###############################################################
    
    ### 2.1 a) Identify the indices of all core points
    
    pair_distance = euclidean_distances(X, X)
    core_point_indices = np.where(np.array(pair_distance < eps).sum(axis=1) >= min_samples)[0]
    
    
    ### Your code ends here #################################################################
    #########################################################################################
    
    
    
    #########################################################################################
    ### Your code starts here ###############################################################
    
    ### 2.1 b) Identify the indices of all noise points ==> noise_point_indices
    
    noise_point_indices = np.where(np.array(pair_distance[:, core_point_indices]  < eps).sum(axis=1) == 0)[0]
    
    ### Your code ends here #################################################################
    #########################################################################################
    
    return core_point_indices, noise_point_indices